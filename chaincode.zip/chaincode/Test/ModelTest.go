package main

import (
	"bytes"
	"encoding/json"
	. "fmt"
	"github.com/hyperledger/fabric/core/chaincode/shim"
	pb "github.com/hyperledger/fabric/protos/peer"
	"io/ioutil"
	"math"
	"net/http"
	"strconv"
	"strings"
)

// SimpleChaincode example simple Chaincode implementation
type SimpleModel struct {}

//storage for model
type Model struct {
	ObjectType 		string
	Name       		string
	Parameters 		[]float64 `json:"Parameters"`
	Owner      		string
}

type ModelFile struct{
	ObjectType 	string
	Name string
	File string
	Owner string
}

type DataForApi struct{
 Data []DataWrapper  `json:"Data"`
 Model []ModelWrapper `json:"Model"`
}

//storage for data
type Data struct{
	ObjectType 	string
	XData string `json:"x"`
	YData string `json:"y"`
	Class string `json:"class"`
	Owner string
}

type Payload struct {
	Data []byte     `json:"Data"`
	Model []byte    `json:"Model"`
}

type ModelWrapper struct{
	Key   string `json:"Key"`
	Record Model `json:"Record"`
}

type DataForApiWrapper struct{
	Key    string `json:"Key"`
	Record DataForApi `json:"Record"`
}

type DataWrapper struct{
	Key    string `json:"Key"`
	Record Data   `json:"Record"`
}
// storage for model results
type Results struct{
	ArrayOfResults     []float64 `json:"Results"`
	ArrayOfResultsMany [][]float64  `json:"ManyResults"`
}

type ResultsArray struct{
	id int64
	Results []float64
	ModelName string
}

var resIdCounter int64 = 0
var currentArrayOfResults []float64

// ===================================================================================
// Main chaincode
// ===================================================================================
func main() {
	if err := shim.Start(new(SimpleModel)); err != nil {
		Printf("Error starting SimpleAsset chaincode: %s", err)
	}
}

// Init initializes chaincode
// ===========================
func (t *SimpleModel) Init(stub shim.ChaincodeStubInterface) pb.Response {
	return shim.Success(nil)
}

// Lists functions available
func (t *SimpleModel) Invoke(stub shim.ChaincodeStubInterface) pb.Response {
	function, args := stub.GetFunctionAndParameters()
	Println("invoke is running " + function)

	// Handle different functions
	if function == "initModel" { //create a new model
		return t.initModel(stub, args)
	} else if function == "readModel" { //read one model from chaincode stateDB
		return t.readModel(stub, args)
	}else if function == "initModelFile" { //read one model from chaincode stateDB
			return t.initModelFile(stub, args)
	} else if function == "initTestData" { //init test data from cli console arguments
		return t.initTestData(stub, args)
	} else if function == "queryDataByOwner" { //read all data owned by same owner
		return t.queryDataByOwner(stub, args)
	}else if function == "validateModel" { //validate single Model
			return t.validateModel(stub, args)
	}else if function == "validateModelAPI" { //validate single Model via Oracle
		return t.validateModelAPI(stub, args)
	}else if function == "updateAllModels" { //validate Many Models
		return t.updateAllModels(stub, args)
	}else if function == "updateAllModelsAPI" { //validate Many Models via Oracle
		return t.updateAllModelsAPI(stub, args)
	}

	Println("invoke did not find func: " + function) //error
	return shim.Error("Received unknown function invocation")
}

// Methods for single Model validation -------------------------------------------------------------------------------
func (t *SimpleModel) validateModel(stub shim.ChaincodeStubInterface, args []string) pb.Response {
	var data []DataWrapper
	var currentModel Model

	modelName:= args[0]
	dataOwner:= args[1]

	//getting data stored in couchDB
	queryString := Sprintf("{\"selector\":{\"ObjectType\": \"data\",\"Owner\": \"%s\"}, \"use_index\": [\"indexOwnerDoc\",\"indexOwner\"]}", dataOwner)
	queryResults, err := getQueryResultForQueryString(stub, queryString)
	if err != nil {
		return shim.Error(err.Error())
	}
	json.Unmarshal((queryResults), &data)
	//--------------------------------------------------
	//getting model stored in couchDB
	valAsbytes, err := stub.GetState(modelName)
	json.Unmarshal((valAsbytes), &currentModel)
	//--------------------------------------------------

	var arrayOfResults []float64
	for i := 0; i < len(data); i++ {
		result := calculateLogisticModelResults(data[i], currentModel)
		arrayOfResults = append(arrayOfResults, result)
	}
	t.initResults(stub,args, modelName, arrayOfResults)
	return shim.Success(nil)
}

func (t *SimpleModel) validateModelAPI(stub shim.ChaincodeStubInterface, args []string) pb.Response {
	modelName:= args[0]
	dataOwner:= args[1]
	var results Results
	var payload Payload

	//getting model stored in couchDB-------------------
	modelJson, err := stub.GetState(modelName)
	//--------------------------------------------------
	//getting data stored in couchDB--------------------
	queryString := Sprintf("{\"selector\":{\"ObjectType\": \"data\",\"Owner\": \"%s\"}, \"use_index\": [\"indexOwnerDoc\",\"indexOwner\"]}", dataOwner)
	dataJson, err := getQueryResultForQueryString(stub, queryString)
	if err != nil {
		return shim.Error(err.Error())
	}
	//--------------------------------------------------

	// setting the ip address of API
	ip :="http://192.168.144.0:8081/"

	//get validation results---------------
	url := ip + "apiValidate"

	payload.Model = modelJson
	payload.Data = dataJson

	payloadbytes, err := json.Marshal(payload)

	responseBytes := HttpPost(url,payloadbytes)

	json.Unmarshal(responseBytes, &results)

	t.initResults(stub,args, modelName, results.ArrayOfResults)
	return shim.Success(nil)
}

//Methods for many Model Testing ----------------------------------------------------------------------------------

func (t *SimpleModel) updateAllModels(stub shim.ChaincodeStubInterface, args []string) pb.Response {

	var data []DataWrapper
	var currentModel Model
	var wrappedModel []ModelWrapper
	dataOwner:= args[1] //change this later

	//getting data stored in couchDB --------------------
	queryString := Sprintf("{\"selector\":{\"ObjectType\": \"data\",\"Owner\": \"%s\"}, \"use_index\": [\"indexOwnerDoc\",\"indexOwner\"]}", dataOwner)
	queryResults, err := getQueryResultForQueryString(stub, queryString)
	if err != nil {
		return shim.Error(err.Error())
	}
	json.Unmarshal((queryResults), &data)

	queryString = Sprintf("{\"selector\":{\"ObjectType\": \"model\",\"Owner\": \"%s\"}, \"use_index\": [\"indexOwnerDoc\",\"indexOwner\"]}", dataOwner)
	println(queryString)
	queryResults, err = getQueryResultForQueryString(stub, queryString)
	println(queryResults)
	if err != nil {
		return shim.Error(err.Error())
	}
	json.Unmarshal((queryResults), &wrappedModel)
	//---------------------------------------------------

	for i := 0; i < len(wrappedModel); i++ {
		currentModel = wrappedModel[i].Record
		//getting model stored in couchDB --------------
		if err != nil {
			return shim.Error(err.Error())
		}

		// -----------------------------------------------
		currentArrayOfResults = []float64{};
		for j := 0; j < len(data); j++ {
			result := calculateLogisticModelResults(data[j], currentModel)
			currentArrayOfResults = append(currentArrayOfResults, result)

		}
		t.initResults(stub,args, currentModel.Name, currentArrayOfResults)
	}
	return shim.Success(nil)
}

func (t *SimpleModel) updateAllModelsAPI(stub shim.ChaincodeStubInterface, args []string) pb.Response {
	dataOwner:= args[1] //change this later
	modelNameBase := "model"
	var results Results
	var payload Payload
	currentArrayOfResults = []float64{}

	// setting the ip address of API
	ip := "http://192.168.144.0:8081/"

	//getting data stored in couchDB--------------------
	queryString := Sprintf("{\"selector\":{\"ObjectType\": \"data\",\"Owner\": \"%s\"}, \"use_index\": [\"indexOwnerDoc\",\"indexOwner\"]}", dataOwner)
	dataJson, err := getQueryResultForQueryString(stub, queryString)
	if err != nil {
		return shim.Error(err.Error())
	}
	//--------------------------------------------------
	//getting model stored in couchDB--------------------
	queryString = Sprintf("{\"selector\":{\"ObjectType\": \"model\",\"Owner\": \"%s\"}, \"use_index\": [\"indexOwnerDoc\",\"indexOwner\"]}", dataOwner)


	modelsJson, err := getQueryResultForQueryString(stub, queryString)
	if err != nil {
		return shim.Error(err.Error())
	}

	//Getting results from all Models from Oracle service
	url := ip + "apiValidateMany"

	payload.Data = dataJson
	payload.Model = modelsJson

	payloadbytes, err := json.Marshal(payload)
	responseBytes := HttpPost(url,payloadbytes)

	//Parsing json form Oracle results and storing them to blockchain
	err = json.Unmarshal(responseBytes, &results)
	if err != nil {
		return shim.Error(err.Error())
	}
	t.initManyResults(stub,args,modelNameBase, results.ArrayOfResultsMany)
	return shim.Success(nil)
}

//Methods to read data form Blockchain ------------------------------------------------------------------------

func (t *SimpleModel) queryDataByOwner(stub shim.ChaincodeStubInterface, args []string) pb.Response {

	if len(args) < 1 {
		return shim.Error("Incorrect number of arguments. Expecting 1")
	}

	owner := args[0]

	queryString := Sprintf("{\"selector\":{\"ObjectType\": \"data\",\"Owner\": \"%s\"}, \"use_index\": [\"indexOwnerDoc\",\"indexOwner\"]}", owner)
	queryResults, err := getQueryResultForQueryString(stub, queryString)

	if err != nil {
		return shim.Error(err.Error())
	}
	return shim.Success(queryResults)
}

func (t *SimpleModel) readModel(stub shim.ChaincodeStubInterface, args []string) pb.Response {
	var name, jsonResp string
	var err error

	if len(args) != 1 {
		return shim.Error("Incorrect number of arguments. Expecting name of the marble to query")
	}

	name = args[0]
	valAsbytes, err := stub.GetState(name) //read model from chaincode state
	if err != nil {
		jsonResp = "{\"Error\":\"Failed to get state for " + name + "\"}"
		return shim.Error(jsonResp)
	} else if valAsbytes == nil {
		jsonResp = "{\"Error\":\"Model does not exist: " + name + "\"}"
		return shim.Error(jsonResp)
	}
	return shim.Success(valAsbytes)
}

//Methods to put data into Blockchain state DB -------------------------------------------------------------------------

func (t *SimpleModel) initTestData(stub shim.ChaincodeStubInterface, args []string) pb.Response {

	owner := args[3]
	objectType := "data"
	currentModelData := &Data{objectType,args[0],args[1],args[2],owner}
	DataJSONasBytes, err := json.Marshal(currentModelData)

	err = stub.PutState(args[4], DataJSONasBytes)
	if err != nil {
		return shim.Error(err.Error())
	}

	return shim.Success(nil)
}

func (t *SimpleModel) initResults(stub shim.ChaincodeStubInterface, args []string, modelName string, results []float64) pb.Response {

	currentResults :=  &ResultsArray{ resIdCounter, results, modelName}

	resultsAsBytes, err := json.Marshal(currentResults)
	key :=  strconv.FormatInt(resIdCounter, 10)
	finalKey := "results" + key
	err = stub.PutState(finalKey , resultsAsBytes)
	if err != nil {
		return shim.Error(err.Error())
	}

	resIdCounter++
	return shim.Success(nil)
}

func (t *SimpleModel) initManyResults(stub shim.ChaincodeStubInterface, args []string, modelNameBase string, results [][]float64) pb.Response {
	for i := 0; i < len(results); i++ {
		modelName := modelNameBase + strconv.Itoa(i)
		currentResults := &ResultsArray{resIdCounter, results[i], modelName}
		resultsAsBytes, err := json.Marshal(currentResults)
		key := strconv.FormatInt(resIdCounter, 10)
		finalKey := "results" + key
		err = stub.PutState(finalKey, resultsAsBytes)
		if err != nil {
			return shim.Error(err.Error())
		}
		resIdCounter++
	}
	return shim.Success(nil)
}

func (t *SimpleModel) initModel(stub shim.ChaincodeStubInterface, args []string) pb.Response {

	var err error

	//   	    0          1        2
	//   "./model.json", "model1", Vaidotas
	// peer chaincode invoke -C myc -n marbles -c '{"Args":["initModel","model.json","model1","Vaidotas"]}'

	model1, err := strconv.ParseFloat(strings.TrimSpace(args[0]), 64);
	model2, err := strconv.ParseFloat(strings.TrimSpace(args[1]), 64);
	model3, err := strconv.ParseFloat(strings.TrimSpace(args[2]), 64);

	parameters := []float64 { model1, model2, model3 }
	modelName := args[3]
	owner := args[4]

	objectType := "model"
	model := &Model{objectType, modelName, parameters, owner}
	modelJSONasBytes, err := json.Marshal(model)

	//size, err := strconv.Atoi(args[2])

	// ==== Check if model already exists ====
	modelAsBytes, err := stub.GetState(modelName)
	if err != nil {
		return shim.Error("Failed to get model: " + err.Error())
	} else if modelAsBytes != nil {
		return shim.Error("This model already exists: " + modelName)
	}

	err = stub.PutState(modelName, modelJSONasBytes)
	if err != nil {
		return shim.Error(err.Error())
	}

	// ==== Model saved . Return success ====

	return shim.Success(nil)
}


func (t *SimpleModel) initModelFile(stub shim.ChaincodeStubInterface, args []string) pb.Response {

	var err error

	//   	    0          1        2
	//   "./model.json", "model1", Vaidotas
	// peer chaincode invoke -C myc -n marbles -c '{"Args":["initModel","model.json","model1","Vaidotas"]}'
	modelName := args[0]
	Base64Model :="'b'UEsDBBQAAAAAAApSiVEAAAAAAAAAAAAAAAAQACAAbHJtX21vZGVsLm1vZGVsL1VUDQAH9aPQX/aj0F/1o9BfdXgLAAEE6AMAAAToAwAAUEsDBBQAAAAAAApSiVEAAAAAAAAAAAAAAAAZACAAbHJtX21vZGVsLm1vZGVsL21ldGFkYXRhL1VUDQAH9KPQX/Wj0F/0o9BfdXgLAAEE6AMAAAToAwAAUEsDBBQACAAIAApSiVEAAAAAAAAAAAAAAAAhACAAbHJtX21vZGVsLm1vZGVsL21ldGFkYXRhL19TVUNDRVNTVVQNAAf0o9Bf86zQX/Sj0F91eAsAAQToAwAABOgDAAADAFBLBwgAAAAAAgAAAAAAAABQSwMEFAAIAAgAClKJUQAAAAAAAAAACAAAACYAIABscm1fbW9kZWwubW9kZWwvbWV0YWRhdGEvLl9TVUNDRVNTLmNyY1VUDQAH9KPQX/aj0F/0o9BfdXgLAAEE6AMAAAToAwAASy5KZmBgYGIAAFBLBwhFpuf8CgAAAAgAAABQSwMEFAAIAAgAClKJUQAAAAAAAAAAHgIAACMAIABscm1fbW9kZWwubW9kZWwvbWV0YWRhdGEvcGFydC0wMDAwMFVUDQAH9KPQX/Wj0F/0o9BfdXgLAAEE6AMAAAToAwAAbVDLTsMwELzzGXsOltNnyBU4VKKo4sAVbexNYuHEkeMIStV/Z51QaFVuHs9jZ/cAymLfQw7OVwI7VDWJvkP/LhorRs6URmEwrhVPrjJ9MOqFKk9MuHbrNFlIIJiG+oBNB3m6kuulzO4ymc3SBMasV/JRzVPmQoqUDYPRjK4D3+RyrQq5WOBCzVnHbmy2yLkH8FTtIoRcinkCDX5uAnmeKBMgbspBzxR+JdkxAU0lDnb6+0nBimdV40IP1IUa8lkCFguy985yp/HJkz1+7Dxpo6Jyoi6+WFJiY+yeCRyCi9iETcuVFOdCHvxAFy25Zog5qZCPtys+TcBWo9fma2xzcpyvyZaSMAx8nanCCcXTeFdgYawJ+4k7+4B/LxIL1GyundURL2PI5Yp/GI7Hm29QSwcImqUhoi4BAAAeAgAAUEsDBBQACAAIAApSiVEAAAAAAAAAABAAAAAoACAAbHJtX21vZGVsLm1vZGVsL21ldGFkYXRhLy5wYXJ0LTAwMDAwLmNyY1VUDQAH9KPQX/Wj0F/0o9BfdXgLAAEE6AMAAAToAwAASy5KZmBgYGKI1v5t2nXNVRsAUEsHCNVikV8SAAAAEAAAAFBLAwQUAAAAAAAKUolRAAAAAAAAAAAAAAAAFQAgAGxybV9tb2RlbC5tb2RlbC9kYXRhL1VUDQAH9aPQX/aj0F/1o9BfdXgLAAEE6AMAAAToAwAAUEsDBBQACAAIAApSiVEAAAAAAAAAAAAAAAAdACAAbHJtX21vZGVsLm1vZGVsL2RhdGEvX1NVQ0NFU1NVVA0AB/Wj0F/zrNBf9aPQX3V4CwABBOgDAAAE6AMAAAMAUEsHCAAAAAACAAAAAAAAAFBLAwQUAAgACAAKUolRAAAAAAAAAAAIAAAAIgAgAGxybV9tb2RlbC5tb2RlbC9kYXRhLy5fU1VDQ0VTUy5jcmNVVA0AB/Wj0F/2o9Bf9aPQX3V4CwABBOgDAAAE6AMAAEsuSmZgYGBiAABQSwcIRabn/AoAAAAIAAAAUEsDBBQACAAIAApSiVEAAAAAAAAAAD8QAABYACAAbHJtX21vZGVsLm1vZGVsL2RhdGEvcGFydC0wMDAwMC00YzI5MzRhNS1mYzk3LTRjZGMtOGQ5NC1jNTA5OGQ2MGM1OWEtYzAwMC5zbmFwcHkucGFycXVldFVUDQAH9aPQX/aj0F/1o9BfdXgLAAEE6AMAAAToAwAA3VVNb+NEGB47bmKFdFcgbDkQViWiVYuClVCabapIaNWCCtKiqApwQAhN7EmxcOysP7qEqhd+ANoLV04c+AGI697Qaq+gFRyp9oKohNgrHPadseM4TtZ1m9UesKzEM/M8z7zzfszbuXHQkJAkSqWaxLMPsaIIPEIo+JXRemwEj1CiH5ejvCgpASXPKBwDcSFlMoKn+Bql5DguIF6RXpgQm3SpoOQYgK6+JF0br+aD1eU6o6MJ5nVJnWAU8Ze7G9+V/rn/9uQLTJgzS7fvxLRyaLyyyHGeFjHF52Ni6PksLsqC2ZHaNUmI3Pjt73/++8c7H4PDvL9fPXrL+usudePsLPBfUZgWn+Pye1fRGDIGJGOscBy8IMb+WbxDRwCAl/KxzOMQvBRJ/+GBH4kv//fyfskdYueLz1ztczLAUhFmV5FStPzBroldl7jBxHMw8S7Bnu/AzBavXDUsjzgaGXofEc2zHUkMcII3GpLVa3TAK4JrfEUoumBYuqERl9qEtgRFMA3Xk/iAUiAmGRDLo8D8ETb9ObhiAve8ZpN+39AMGN/EnmN8KV2ZMQAoYPWBfdudjHZtk9lf0Gyz4znnW1R07NvvPU3rJQSjkuF2HWy5Q9slejC1bLg3fdMzLHtgYBPJfLlSPlsTKxClVSSW4yGReJmXe3J/TWynZHe5ItFcpN9rViQTD2SkY2XV+ZWjQlsoL5bXkynAPM8kLdkBZDulZOOaP/MpmjSDmOa23AZkGwouzv06FxwsX95PUsc5x6Iw9j6T2pP3gZiUug9SxflSYVxnlb7n5B84YLYvcFXG93wkTI4+m9LTDn0kZHXow6U01XFNRMIPl7IKP8ifJ0zLKxJ+kM+aVvcKURjn6IalOj+Q9wrJQN4RU8Ri5Txf746Y1PtNjBJjVu8JqSHIP3LyTxxw2xe4/uO7flOEwRN9PXV/MNs7chc47URHiCueMkV2CUzfNdHZTyl/qk/E+PJZUQbH1BTFdg5VPMTQMFTWO9Qj4riGbSlLm2pdbSBlYwbh3jJV+LjlE0+FCKgD4mEde1g5LR1XaZpXd6qu5/iaV61V+wYxdbe688lx1cIDujS5+mA5hNMaPSQOTFi+aeKeCZN9bLqkVh2rV3eOT05qcZXxzbeITOJyiKSig/g6PYVGDYbRjC8GpmoaFjYP1UDgw70uwIej3ZAwHKXhwJPd6e1S/MYQ0VF7I49c4Jz06k33E2yc5iZWZbPuwY6DRzAdVks3qa/ZlocNy/0A9gltPMm8a1COWTfVbZ9KXmrPT0+yWzVTvwskTSBwftLEcc8uacLmsmCZ0jayiETYMZ5x7k1ay/826WPlHWtAsWyxbZNg69xQXaR4pnrVZbZCyvth73lj4KyEzWqloTagWa2s93zD1Ffwdkvvb/dbrc03e03SbzY3N/V6s95ska261updb12v90hPb2yUzyoIZXxRbxmhzo2DxmNQSwcIi3KsJ0YEAAA/EAAAUEsDBBQACAAIAApSiVEAAAAAAAAAACwAAABdACAAbHJtX21vZGVsLm1vZGVsL2RhdGEvLnBhcnQtMDAwMDAtNGMyOTM0YTUtZmM5Ny00Y2RjLThkOTQtYzUwOThkNjBjNTlhLWMwMDAuc25hcHB5LnBhcnF1ZXQuY3JjVVQNAAf1o9Bf9qPQX/Wj0F91eAsAAQToAwAABOgDAABLLkpmYGBgYtjna7Ffa/VkFymPN+G30pNtZOWvPw9TszN6dMI+IbmXc7KokdxnAFBLBwj1b9iDLwAAACwAAABQSwECFAMUAAAAAAAKUolRAAAAAAAAAAAAAAAAEAAgAAAAAAAAAAAA7UEAAAAAbHJtX21vZGVsLm1vZGVsL1VUDQAH9aPQX/aj0F/1o9BfdXgLAAEE6AMAAAToAwAAUEsBAhQDFAAAAAAAClKJUQAAAAAAAAAAAAAAABkAIAAAAAAAAAAAAO1BTgAAAGxybV9tb2RlbC5tb2RlbC9tZXRhZGF0YS9VVA0AB/Sj0F/1o9Bf9KPQX3V4CwABBOgDAAAE6AMAAFBLAQIUAxQACAAIAApSiVEAAAAAAgAAAAAAAAAhACAAAAAAAAAAAACkgaUAAABscm1fbW9kZWwubW9kZWwvbWV0YWRhdGEvX1NVQ0NFU1NVVA0AB/Sj0F/zrNBf9KPQX3V4CwABBOgDAAAE6AMAAFBLAQIUAxQACAAIAApSiVFFpuf8CgAAAAgAAAAmACAAAAAAAAAAAACkgRYBAABscm1fbW9kZWwubW9kZWwvbWV0YWRhdGEvLl9TVUNDRVNTLmNyY1VUDQAH9KPQX/aj0F/0o9BfdXgLAAEE6AMAAAToAwAAUEsBAhQDFAAIAAgAClKJUZqlIaIuAQAAHgIAACMAIAAAAAAAAAAAAKSBlAEAAGxybV9tb2RlbC5tb2RlbC9tZXRhZGF0YS9wYXJ0LTAwMDAwVVQNAAf0o9Bf9aPQX/Sj0F91eAsAAQToAwAABOgDAABQSwECFAMUAAgACAAKUolR1WKRXxIAAAAQAAAAKAAgAAAAAAAAAAAApIEzAwAAbHJtX21vZGVsLm1vZGVsL21ldGFkYXRhLy5wYXJ0LTAwMDAwLmNyY1VUDQAH9KPQX/Wj0F/0o9BfdXgLAAEE6AMAAAToAwAAUEsBAhQDFAAAAAAAClKJUQAAAAAAAAAAAAAAABUAIAAAAAAAAAAAAO1BuwMAAGxybV9tb2RlbC5tb2RlbC9kYXRhL1VUDQAH9aPQX/aj0F/1o9BfdXgLAAEE6AMAAAToAwAAUEsBAhQDFAAIAAgAClKJUQAAAAACAAAAAAAAAB0AIAAAAAAAAAAAAKSBDgQAAGxybV9tb2RlbC5tb2RlbC9kYXRhL19TVUNDRVNTVVQNAAf1o9Bf86zQX/Wj0F91eAsAAQToAwAABOgDAABQSwECFAMUAAgACAAKUolRRabn/AoAAAAIAAAAIgAgAAAAAAAAAAAApIF7BAAAbHJtX21vZGVsLm1vZGVsL2RhdGEvLl9TVUNDRVNTLmNyY1VUDQAH9aPQX/aj0F/1o9BfdXgLAAEE6AMAAAToAwAAUEsBAhQDFAAIAAgAClKJUYtyrCdGBAAAPxAAAFgAIAAAAAAAAAAAAKSB9QQAAGxybV9tb2RlbC5tb2RlbC9kYXRhL3BhcnQtMDAwMDAtNGMyOTM0YTUtZmM5Ny00Y2RjLThkOTQtYzUwOThkNjBjNTlhLWMwMDAuc25hcHB5LnBhcnF1ZXRVVA0AB/Wj0F/2o9Bf9aPQX3V4CwABBOgDAAAE6AMAAFBLAQIUAxQACAAIAApSiVH1b9iDLwAAACwAAABdACAAAAAAAAAAAACkgeEJAABscm1fbW9kZWwubW9kZWwvZGF0YS8ucGFydC0wMDAwMC00YzI5MzRhNS1mYzk3LTRjZGMtOGQ5NC1jNTA5OGQ2MGM1OWEtYzAwMC5zbmFwcHkucGFycXVldC5jcmNVVA0AB/Wj0F/2o9Bf9aPQX3V4CwABBOgDAAAE6AMAAFBLBQYAAAAACwALAB4FAAC7CgAAAAA='"


objectType := "modelFile"
	model := &ModelFile{objectType, modelName,Base64Model,"Vaidas"}
	modelJSONasBytes, err := json.Marshal(model)

	//size, err := strconv.Atoi(args[2])

	// ==== Check if model already exists ====
	modelAsBytes, err := stub.GetState(modelName)
	if err != nil {
		return shim.Error("Failed to get model: " + err.Error())
	} else if modelAsBytes != nil {
		return shim.Error("This model already exists: " + modelName)
	}

	err = stub.PutState(modelName, modelJSONasBytes)
	if err != nil {
		return shim.Error(err.Error())
	}

	// ==== Model saved . Return success ====

	return shim.Success(nil)
}

//Methods for parsing blockchain data -----------------------------------------------------------------------

func getQueryResultForQueryString(stub shim.ChaincodeStubInterface, queryString string) ([]byte, error) {

	resultsIterator, err := stub.GetQueryResult(queryString)
	if err != nil {
		return nil, err
	}
	defer resultsIterator.Close()

	buffer, err := constructQueryResponseFromIterator(resultsIterator)
	if err != nil {
		return nil, err
	}

	return buffer.Bytes(), nil
}

func constructQueryResponseFromIterator(resultsIterator shim.StateQueryIteratorInterface) (*bytes.Buffer, error) {
	// buffer is a JSON array containing QueryResults
	var buffer bytes.Buffer
	buffer.WriteString("[")

	bArrayMemberAlreadyWritten := false
	for resultsIterator.HasNext() {
		queryResponse, err := resultsIterator.Next()
		if err != nil {
			return nil, err
		}
		// Add a comma before array members, suppress it for the first array member
		if bArrayMemberAlreadyWritten == true {
			buffer.WriteString(",")
		}
		buffer.WriteString("{\"Key\":")
		buffer.WriteString("\"")
		buffer.WriteString(queryResponse.Key)
		buffer.WriteString("\"")

		buffer.WriteString(", \"Record\":")
		// Record is a JSON object, so we write as-is
		buffer.WriteString(string(queryResponse.Value))
		buffer.WriteString("}")
		bArrayMemberAlreadyWritten = true
	}
	buffer.WriteString("]")

	return &buffer, nil
}

//Non blockchain functions ----------------------------------------------------------------------------------

func calculateLogisticModelResults(data DataWrapper, currentModel Model ) float64{

	var currentX float64
	var currentY float64
	currentX, _=strconv.ParseFloat(data.Record.XData,64)
	currentY, _=strconv.ParseFloat(data.Record.YData,64)

	sum:= currentModel.Parameters[0]
	sum += currentX * currentModel.Parameters[1]
	sum += currentY * currentModel.Parameters[2]
	result := 1 / (1 + math.Exp(-sum))

	return result
}

func HttpPost(url string , data []byte) []byte{
	resp, err := http.Post(url,"application/json", bytes.NewBuffer(data))
	if err != nil {
		print(err)
	}
	defer resp.Body.Close()
	body, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		print(err)
	}
	return body
}

/*func  HttpGet(url string) []byte {
	var data []byte
	response, err := http.Get(url)
	if err != nil {
		Printf("The HTTP request failed with error %s\n", err)
	} else {
		data, _ = ioutil.ReadAll(response.Body)
	}
	return data
}*/







