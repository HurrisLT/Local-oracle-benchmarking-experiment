#!/bin/bash
cd /home/vdledger/onefourlatest/fabric-samples/chaincode/scripts || return 99
total=$(<./blocks/amount.txt)
cd /home/vdledger/onefourlatest/fabric-samples/chaincode
for (( i=10224; i<=total-1; i++ ))
do
   Command="../bin/configtxgen -configPath ../config/ -inspectBlock ./scripts/blocks/myc_$i.block > ./blocksJson/$i.json"
   eval "$Command"
done



