#!/bin/bash

bash ImportModel13.sh
sleep 10
bash importData13.sh
sleep 10
bash update13.sh
sleep 60
bash updateeAPI13.sh
sleep 60
