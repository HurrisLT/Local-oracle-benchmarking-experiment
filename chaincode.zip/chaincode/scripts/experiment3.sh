#!/bin/bash

bash ImportModelE3.sh
sleep 10
bash importDataE3.sh
sleep 10
bash validate3.sh
sleep 10
bash validateAPI3.sh
sleep 10

