#!/bin/bash

bash ImportModelE5.sh
sleep 10
bash importDataE5.sh
sleep 10
bash validate5.sh
sleep 30
bash validateAPI5.sh

