#!/bin/bash

bash ImportModelE21.sh
sleep 10
bash importDataE21.sh
sleep 10
bash validate21.sh
sleep 10
bash validateAPI21.sh

