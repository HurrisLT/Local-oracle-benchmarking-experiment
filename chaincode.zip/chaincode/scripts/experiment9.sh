#!/bin/bash

bash ImportModelE9.sh
sleep 10
bash importDataE9.sh
sleep 10
bash validate9.sh
sleep 10
bash validateAPI9.sh

