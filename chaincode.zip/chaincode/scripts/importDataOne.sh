#!/bin/bash
# Purpose: Read Comma Separated CSV File
# Author: Vivek Gite under GPL v2.0+
# ------------------------------------------
INPUT="../data/data100000.csv"
OLDIFS=$IFS
IFS=','
I=0
Command=""
Args=""
FullCMD=""
[ ! -f $INPUT ] && { echo "$INPUT file not found"; exit 99; }
while read x y res
do
  Command="peer chaincode invoke -n model -c "
  Args=$(echo "'{\"Args\":[\"initTestData\",\"$x\",\"$y\",\"$res\",\"Vaidotas\",\"Data$I\"]}' -C myc" |tr -d '\r')
  eval "$Command $Args"
  echo "$Command $Args" |tr -d '\r'
  I=$((I + 1))
done < $INPUT
IFS=$OLDIFS
