#!/bin/bash
# Purpose: Read Comma Separated CSV File
# Author: Vivek Gite under GPL v2.0+
# ------------------------------------------
INPUT="../dataExp2/EEG16.csv"
OLDIFS=$IFS
IFS=','
I=0
Command=""
Args=""
FullCMD=""   
[ ! -f $INPUT ] && { echo "$INPUT file not found"; exit 99; }
while read x1 x2 x3 x4 x5 x6 x7 x8 x9 x10 x11 x12 x13 x14 res
do
  Command="peer chaincode invoke -n model -c '{\"Args\":[\"initTestData\",\"Data$I\",\"Vaidotas\",\"$x1\",\"$x2\",\"$x3\",\"$x4\",\"$x5\",\"$x6\",\"$x7\",\"$x8\",\"$x9\",\"$x10\",\"$x11\",\"$x12\",\"$x13\",\"$x14\",\"$res\"]}' -C myc --peerAddresses peer0.org1.example.com:7051 --peerAddresses peer1.org1.example.com:7057 --peerAddresses peer2.org1.example.com:7060 --peerAddresses peer3.org1.example.com:7063 --peerAddresses peer4.org1.example.com:7066 --peerAddresses peer5.org1.example.com:7069 --peerAddresses peer6.org1.example.com:7072 --peerAddresses peer7.org1.example.com:7075 --peerAddresses peer8.org1.example.com:7078 --peerAddresses peer9.org1.example.com:7081 --peerAddresses peer10.org1.example.com:7084"
  eval "$Command"
  #echo "$Command $Args" |tr -d '\r'
  I=$((I + 1))
done < $INPUT
IFS=$OLDIFS
