#!/bin/bash

bash ImportModel3.sh
sleep 10
bash importData3.sh
sleep 10
bash validate3.sh
sleep 10
bash validateAPI3.sh
