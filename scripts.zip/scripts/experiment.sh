#!/bin/bash

DATA=$1
PEERAMOUNT=$
bash ImportModel.sh
bash importData$1.sh
bash validate$2.sh
bash validateAPI$2.sh
bash update$2.sh
bash updateAPI$2.sh

#docker logs peer0.org1.example.com 2>&1 | grep "\[endorser\]" | cut -d ' ' -f 13| tail -n 400 > Exp1Data8Peers2.txt



