#!/bin/bash
# Purpose: Read Comma Separated CSV File
# Author: Vivek Gite under GPL v2.0+
# ------------------------------------------
INPUT="../models.csv"
OLDIFS=$IFS
IFS=','
I=0
Command1=""
Command2=""
Args=""
FullCMD=""
[ ! -f $INPUT ] && { echo "$INPUT file not found"; exit 99; }
while read x1 x2 x3
do
  sleep 20
  Command="peer chaincode invoke -n model -c "
  Args=$(echo "'{\"Args\":[\"validateModel\",\"model$I\",\"Vaidotas\"]}' -C myc " |tr -d '\r')
  eval "$Command $Args"
  echo "$Command $Args" |tr -d '\r'

#  Command2="peer chaincode invoke -n model -c "
#  Args=$(echo "'{\"Args\":[\"validateModelAPI\",\"model$I\",\"Vaidotas\"]}' -C myc" |tr -d '\r')
 # eval "$Command2 $Args"
#  echo "$Command2 $Args" |tr -d '\r'

  I=$((I + 1))
done < $INPUT
IFS=$OLDIFS
