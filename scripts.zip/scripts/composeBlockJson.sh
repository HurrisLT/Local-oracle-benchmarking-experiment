#!/bin/bash
total=$(peer channel getinfo -c myc | grep -o -P '(?<=\"height\"\:).*(?=\,\"currentBlockHash\")')
echo "$total" > ./blocks/amount.txt
Command=""
for (( i=11243; i<=total-1; i++ ))
do
   Command="peer channel fetch $i -c myc ./blocks/myc_$i.block "
   eval "$Command"
done

