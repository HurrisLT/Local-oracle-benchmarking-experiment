#!/bin/bash

bash ImportModel7.sh
sleep 10
bash importData7.sh
sleep 10
bash validate7.sh
sleep 60
bash validateAPI7.sh


