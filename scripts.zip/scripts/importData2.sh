#!/bin/bash
# Purpose: Read Comma Separated CSV File
# Author: Vivek Gite under GPL v2.0+
# ------------------------------------------
INPUT="../data/data2048.csv"
OLDIFS=$IFS
IFS=','
I=0
Command=""
Args=""
FullCMD=""
[ ! -f $INPUT ] && { echo "$INPUT file not found"; exit 99; }
while read x y res
do
  Command="peer chaincode invoke -n model -c '{\"Args\":[\"initTestData\",\"$x\",\"$y\",\"$res\",\"Vaidotas\",\"Data$I\"]}' -C myc --peerAddresses peer0.org1.example.com:7051 --peerAddresses peer1.org1.example.com:7057"
 eval "$Command" 

  I=$((I + 1))
done < $INPUT
IFS=$OLDIFS
