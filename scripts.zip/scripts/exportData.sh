#!/bin/bash
# Purpose: Read Comma Separated CSV File
# Author: Vivek Gite under GPL v2.0+
I=0
Command=""

for (( i=1; i<=$1; i++ ))
do  
   eval "docker logs peer$i.org1.example.com  2>&1 | grep '' > peer"$i"data32APIrerun.log"
done


