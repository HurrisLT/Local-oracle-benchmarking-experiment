#!/bin/bash
# Purpose: Read Comma Separated CSV File
# Author: Vivek Gite under GPL v2.0+
# ------------------------------------------
INPUT="../models.csv"
OLDIFS=$IFS
IFS=','
I=0
Command1=""
Command2=""
Args=""
FullCMD=""
[ ! -f $INPUT ] && { echo "$INPUT file not found"; exit 99; }
while read x1 x2 x3
do 
  Command2="peer chaincode invoke -n model -c '{\"Args\":[\"validateModelAPI\",\"model$I\",\"Vaidotas\"]}' -C myc --peerAddresses peer0.org1.example.com:7051 --peerAddresses peer1.org1.example.com:7057 --peerAddresses peer2.org1.example.com:7060 --peerAddresses peer3.org1.example.com:7063 --peerAddresses peer4.org1.example.com:7066 --peerAddresses peer5.org1.example.com:7069 --peerAddresses peer6.org1.example.com:7072 --peerAddresses peer7.org1.example.com:7075"
  eval "$Command2"
  I=$((I + 1))
done < $INPUT
IFS=$OLDIFS
