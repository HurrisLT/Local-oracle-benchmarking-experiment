#!/bin/bash
# Purpose: Read Comma Separated CSV File
# Author: Vivek Gite under GPL v2.0+
# ------------------------------------------
INPUT="../models.csv"
OLDIFS=$IFS
IFS=','
I=0
Command1=""
Command2=""
Args=""
FullCMD=""
[ ! -f $INPUT ] && { echo "$INPUT file not found"; exit 99; }
while read x1 x2 x3
do
  Command="peer chaincode invoke -n model -c '{\"Args\":[\"updateAllModelsAPI\",\"model$I\",\"Vaidotas\"]}' -C myc --peerAddresses peer0.org1.example.com:7051 --peerAddresses peer1.org1.example.com:7057"
  eval "$Command $Args"
  I=$((I + 1))
done < $INPUT
IFS=$OLDIFS
