#!/bin/bash
# Purpose: Read Comma Separated CSV File
# Author: Vivek Gite under GPL v2.0+
# ------------------------------------------

Command=""
Args=""
FullCMD=""

Command=""
cd /opt/gopath/src/github.com/hyperledger/fabric/peer

Args=$(echo "peer chaincode install -p chaincodedev/chaincode/Test -n model -v 0" |tr -d '\r')
eval "$Command $Args"
echo "$Command $Args" |tr -d '\r'

Command="CORE_PEER_ADDRESS=peer1.org1.example.com:7057"
Args=$(echo "peer chaincode install -p chaincodedev/chaincode/Test -n model -v 0" |tr -d '\r')
eval "$Command $Args"
echo "$Command $Args" |tr -d '\r'

Command="CORE_PEER_ADDRESS=peer2.org1.example.com:7060"
Args=$(echo "peer chaincode install -p chaincodedev/chaincode/Test -n model -v 0" |tr -d '\r')
eval "$Command $Args"
echo "$Command $Args" |tr -d '\r'



